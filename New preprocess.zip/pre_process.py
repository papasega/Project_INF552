import numpy as np
import pandas as pd
from sklearn.preprocessing import Imputer
from sklearn.preprocessing import scale
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LogisticRegression
from Dung_gini import gini

def pre_process(train,test,k,v,polynome):
    """
    Inputs:
    train and test must be obtained by pd.read_csv
    We will polynomialize to degree k the v most important numerical variables, if polynome = True
    Example: k = 2, v = 10, polynome=True, note: we need v<=26 (or v<26, I'm not sure)
    If polynome=False, then k and v can be anything, they have no effect.

    Outputs:
    List of 4 elements:
    - train_es: the processed training matrix, in format numpy, without id and target
    - train_target: type numpy
    - test_es: the processed testing matrix, in format numpy, without id
    - test_id: type numpy

    Warning:
    This function may change the train and test variables!
    """
    # Read data, back up necessary but cubersome variables (id,target) then throw them away
    train_id = train['id'].values
    train_target = train['target'].values
    test_id = test['id'].values
    train = train.drop('target',axis=1)
    train = train.drop('id',axis=1)
    test = test.drop('id',axis=1) #train and test are now fixed and will longer change

    # Separating num and cat in train and test
    heap = pd.concat([train,test],axis=0) #concatening train and cat to make sure that categorical variables are treated correctly
    cat_columns = [col for col in heap.columns if (('bin' in col)|('cat' in col))]
    num_columns = [col for col in heap.columns if (('bin' not in col) and ('cat' not in col) and (col!='id') and (col!='target'))]
    heap_num = heap[num_columns].values
    heap_cat = heap[cat_columns]
    heap_cat = pd.get_dummies(heap_cat,columns=heap_cat.columns,drop_first=True).values
    train_num = heap_num[0:len(train),:]
    train_cat = heap_cat[0:len(train),:]
    test_num = heap_num[len(train):,:]
    test_cat = heap_cat[len(train):,:]

    # Imputing missing numerical values by their means
    imp = Imputer(missing_values=-1,strategy='mean',axis=0)
    imp.fit(train_num)
    train_num = imp.transform(train_num)
    test_num = imp.transform(test_num)

    # Scaling data, including dummy columns
    mean_train_num = np.mean(train_num,axis=0)
    sd_train_num = np.std(train_num,axis=0)
    train_num = (train_num - mean_train_num)/sd_train_num
    test_num = (test_num - mean_train_num)/sd_train_num
    mean_train_cat = np.mean(train_cat,axis=0)
    sd_train_cat = np.std(train_cat,axis=0)
    train_cat = (train_cat - mean_train_cat)/sd_train_cat
    test_cat = (test_cat - mean_train_cat)/sd_train_cat

    if (polynome):
        # Choosing v numerical variables most correlated with the target in the training set, then polynomialize them to order k
        train_target_scl = (train_target-np.mean(train_target))/np.std(train_target)
        fea_cov = np.abs(train_target_scl.dot(train_num)) #fea_cov[i] is abs of the not-divided-by-n covariance between the scaled target
        # and the feature [i] of the training set
        imp_fea = np.argsort(-fea_cov)[0:v] #the v most important features
        heap_num = np.concatenate((train_num,test_num),axis=0)
        heap_num_1 = heap_num[:,imp_fea] # we will polynomialize this matrix
        heap_num_0 = np.delete(heap_num,imp_fea,axis=1)
        # Start polynomializing
        poly = PolynomialFeatures(degree=k,include_bias=False)
        heap_num_1 = poly.fit_transform(heap_num_1)
        # Reseparate
        heap_num = np.concatenate((heap_num_0,heap_num_1),axis=1)
        train_num = heap_num[0:len(train),:]
        test_num = heap_num[len(train):,:]

    # Give out the processed matrices
    train_es = np.concatenate((train_num,train_cat),axis=1) #esential of the processed training matrix, without id and target
    test_es = np.concatenate((test_num,test_cat),axis=1) #essential of the processed testing matrix, without id

    return train_es,train_target,test_es,test_id
